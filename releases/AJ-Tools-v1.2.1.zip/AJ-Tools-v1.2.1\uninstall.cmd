@echo off
setlocal

set SCRIPT_DIR=%~dp0
powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%uninstall.ps1"
if %errorlevel% neq 0 (
    echo Uninstall failed. Check the PowerShell output above.
    pause
    exit /b %errorlevel%
)

echo AJ Tools removed for current user.
echo To remove all-users install, run uninstall-all-users.cmd as Administrator.
pause
